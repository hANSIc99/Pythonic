

class MyClass:

    def __init__(self, integer):

        self.integer = integer

    def show(self):
        print(self.integer)
