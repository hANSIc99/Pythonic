import sys


if __name__ == '__main__':
    cmd = sys.stdin.read(1) # reads one byte at a time
    print(cmd)

"""
class MyClass:

    def __init__(self, integer):

        self.integer = integer

    def show(self):
        print(self.integer)
"""
